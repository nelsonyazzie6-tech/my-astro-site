---
title: "Database Design Lessons From My SQL Server Course"
pubDate: 2025-02-28
description: "ERD normalization, stored procedures, and the SPJ schema — breaking down what actually clicked for me this semester."
author: "Nelzony"
tags: ["databases", "sql", "school"]
---

# Database Design Lessons From My SQL Server Course

Database Management was one of those courses I expected to be dry. Turns out, once things click, there's something genuinely satisfying about designing a clean schema. Here's what I took away.

## The SPJ Schema

A lot of our exercises used the classic **Suppliers–Parts–Jobs (SPJ)** schema. Three tables, three relationships, and an endless supply of JOIN practice:

```sql
-- Suppliers
CREATE TABLE S (
  sno   VARCHAR(5) PRIMARY KEY,
  sname VARCHAR(50),
  city  VARCHAR(50)
);

-- Parts
CREATE TABLE P (
  pno   VARCHAR(5) PRIMARY KEY,
  pname VARCHAR(50),
  color VARCHAR(20)
);

-- Jobs
CREATE TABLE J (
  jno   VARCHAR(5) PRIMARY KEY,
  jname VARCHAR(50),
  city  VARCHAR(50)
);

-- SPJ: which supplier delivers which part to which job
CREATE TABLE SPJ (
  sno VARCHAR(5) REFERENCES S(sno),
  pno VARCHAR(5) REFERENCES P(pno),
  jno VARCHAR(5) REFERENCES J(jno),
  qty INT,
  PRIMARY KEY (sno, pno, jno)
);
```

Simple on the surface, but you can write surprisingly complex queries on it.

## ERD Normalization

The normalization assignments were the toughest conceptually. The goal: eliminate redundant data by decomposing tables correctly.

Key normal forms I worked through:

1. **1NF** — No repeating groups, every cell holds one value.
2. **2NF** — No partial dependencies (every non-key attribute depends on the *whole* key).
3. **3NF** — No transitive dependencies (non-key attributes don't depend on other non-key attributes).

The **EMP/DEPT/ASSIGNED** table design quiz was a good test of 2NF and 3NF in practice.

## Stored Procedures

My favorite part of the course was stored procedures. Parameterized, reusable SQL that lives in the database:

```sql
CREATE PROCEDURE GetSuppliersByCity
  @city VARCHAR(50)
AS
BEGIN
  SELECT sno, sname
  FROM S
  WHERE city = @city;
END;
```

Call it with:

```sql
EXEC GetSuppliersByCity @city = 'London';
```

Separating query logic from application code, enforcing a consistent API for the database — it's good engineering regardless of your language.

## What Stuck With Me

The big lesson wasn't any specific SQL syntax. It was **thinking in relationships**. Databases force you to model reality precisely — who owns what, what belongs to what, what can exist independently and what can't.

That mental model carries over everywhere: system design, API design, even project planning.

Databases aren't boring. They're just precise.
