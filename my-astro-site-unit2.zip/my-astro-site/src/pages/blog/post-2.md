---
title: "What I Learned Building My First Astro Site"
pubDate: 2025-02-03
description: "Astro's file-based routing, component islands, and zero JS by default — a first impression from someone coming from plain HTML."
author: "Nelzony"
tags: ["web dev", "astro", "learning"]
---

# What I Learned Building My First Astro Site

Coming from plain HTML, CSS, and vanilla JavaScript, picking up Astro felt both familiar and mind-bending at the same time.

## File-Based Routing Just Works

One of the first things that clicked was that **every `.astro` file inside `src/pages/` becomes a URL**. No router configuration. No `app.use()` calls. Drop a file in the folder and it's live.

```
src/pages/index.astro     →  /
src/pages/about.astro     →  /about/
src/pages/blog/index.astro →  /blog/
```

Coming from setting up Express routes manually, this felt like magic.

## The Frontmatter Section

Every `.astro` file has two parts separated by `---` fences:

```astro
---
// This is JavaScript — runs at BUILD time, not in the browser
const name = "Nelzony";
const skills = ["HTML", "CSS", "JS"];
---

<!-- This is the HTML template -->
<h1>Hello, {name}</h1>
<ul>
  {skills.map(skill => <li>{skill}</li>)}
</ul>
```

That `{}` syntax lets you inject JavaScript expressions directly into the HTML. No template literals, no concatenation — clean and readable.

## Markdown for Blog Posts

This one was huge. Instead of writing a blog post as a full `.astro` file, you just write a `.md` file:

```markdown
---
title: "My Post Title"
pubDate: 2025-01-15
---

# My Post Title

Regular Markdown content here. **Bold**, *italic*, lists, code blocks...
```

Astro converts it to a full HTML page automatically. No plugins to configure (for basic use), no extra setup.

## Scoped Styles

Add a `<style>` tag to any `.astro` file and the styles are **automatically scoped** to that file. No class name collisions, no CSS modules setup — it just works.

```astro
<style>
  h1 {
    color: purple; /* Only affects h1 on THIS page */
  }
</style>
```

For global styles, you create a `.css` file and import it in your frontmatter.

## What's Next

I'm still early in the tutorial but already impressed by how fast Astro builds feel. Static-first with optional JavaScript where you actually need it — that's a philosophy I can get behind.

Next up: layouts and reusable components.
