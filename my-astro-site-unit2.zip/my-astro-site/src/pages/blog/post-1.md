---
title: "Why I'm Learning Web Development as a Future Firefighter"
pubDate: 2025-01-15
description: "Most people are surprised when I tell them my plan. Here's how a CIS degree and a fire academy fit together."
author: "Nelzony"
tags: ["personal", "career", "firefighting"]
---

# Why I'm Learning Web Development as a Future Firefighter

Most people raise an eyebrow when I explain my path. *"You're studying computer science… to become a firefighter?"*

Yes. And it makes complete sense to me.

## The Plan in a Nutshell

I'm finishing my **Bachelor of Science in Computer Information Systems** at Fort Lewis College in May 2026. After graduation I'm moving to Albuquerque, NM to complete EMT-Basic training, get my NREMT certification, and apply to Albuquerque Fire Rescue.

Firefighting isn't a detour — it's the bridge. A stable, well-paying career in public service will let me fund the next chapter: an **MS in Cybersecurity** from NAU's online program, starting around Spring 2028.

## Why Not Go Straight Into Tech?

I could. I have the skills. But I've always been drawn to hands-on, high-stakes work. A desk job right out of college doesn't appeal to me — at least not yet. Firefighting means being physically active, working closely with a team, and genuinely helping people in the worst moments of their lives.

Tech can wait. The mission can't.

## What Web Dev Teaches Me

Even if I don't go into software engineering full-time, every course I take in web development sharpens skills that matter everywhere:

- **Problem-solving** — Debugging a broken layout is practice for diagnosing a problem under pressure.
- **Documentation** — Writing clean code comments builds the same habit as writing clear incident reports.
- **Systems thinking** — Understanding how a web app fits together prepares you for understanding how an organization or emergency response chain fits together.

## Where Astro Comes In

This semester I started learning [Astro](https://astro.build) for my web development course. Astro's philosophy — ship less JavaScript, focus on content — resonates with me. Simple, fast, purposeful. Kind of like good emergency response.

---

If you're on an unconventional path too, don't let anyone talk you out of it. The unusual route often leads somewhere more interesting.
