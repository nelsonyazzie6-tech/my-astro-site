---
title: "Why I'm Learning Web Development as a Future Firefighter"
pubDate: 2025-01-15
description: "Most people are surprised when I tell them my plan. Here's how a CIS degree and a fire academy fit together."
author: "Nelzony"
tags: ["personal", "career", "firefighting"]
---

# Why I'm Learning Web Development as a Future Firefighter

Everyone I tell this to gives me the same look.

Like, "you're doing computer science... to be a firefighter?" Yeah. That's the plan.

## Here's the short version

Graduating May 2026 with a BS in CIS from Fort Lewis. After that I'm moving to Albuquerque, doing EMT training, and applying to Albuquerque Fire Rescue. Once I'm hired and stable, I'm going back to school online for a cybersecurity master's.

So the degree isn't wasted. It's just not the first stop.

## Why not just go into tech right away

Honestly I could. But sitting at a desk all day right out of college doesn't really appeal to me. I want to do something hands on. Firefighting is physical, the team aspect is real, and you're helping people on their worst days.

Tech will still be there.

## So why bother with web dev then

Even if I'm not coding for a living, this stuff carries over. Debugging teaches you to think through problems. Writing clean code is just being organized. It's useful no matter what you end up doing.

Also this is a required class so I don't really have a choice lol.

## Astro so far

We're using Astro this semester. I didn't know what it was before this class. It's pretty simple once you get the file structure down. Mostly just HTML with some extra stuff on top.

We'll see how the rest of the semester goes.
