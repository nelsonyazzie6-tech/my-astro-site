---
title: "Database Design Lessons From My SQL Server Course"
pubDate: 2025-02-28
description: "ERD normalization, stored procedures, and the SPJ schema — breaking down what actually clicked for me this semester."
author: "Nelzony"
tags: ["databases", "sql", "school"]
---

# Database Design Lessons From My SQL Server Course

I thought this class was going to be boring. It kind of was at first. But once things started clicking it got more interesting.

## The SPJ schema

We used this a lot. Suppliers, Parts, Jobs. Three tables that connect to each other. Most of our query assignments were built around it.

```sql
CREATE TABLE S (
  sno   VARCHAR(5) PRIMARY KEY,
  sname VARCHAR(50),
  city  VARCHAR(50)
);

CREATE TABLE SPJ (
  sno VARCHAR(5) REFERENCES S(sno),
  pno VARCHAR(5) REFERENCES P(pno),
  jno VARCHAR(5) REFERENCES J(jno),
  qty INT,
  PRIMARY KEY (sno, pno, jno)
);
```

Simple setup but you can write a lot of different queries on it. Good practice.

## Normalization

This was the hardest part for me to wrap my head around. The point is to remove duplicate data by splitting things into separate tables the right way.

The three we covered:

- **1NF** — each cell has one value, no repeating groups
- **2NF** — every column depends on the full primary key, not just part of it
- **3NF** — columns only depend on the primary key, not on each other

The EMP/DEPT/ASSIGNED quiz was basically testing if you understood 2NF and 3NF. Took me a couple tries to get it right.

## Stored procedures

These were actually cool. You write a block of SQL once, save it, and call it whenever you need it.

```sql
CREATE PROCEDURE GetSuppliersByCity
  @city VARCHAR(50)
AS
BEGIN
  SELECT sno, sname FROM S WHERE city = @city;
END;
```

Then you just run:

```sql
EXEC GetSuppliersByCity @city = 'London';
```

Way cleaner than rewriting the same query over and over.

## What I took away

The biggest thing was just learning to think about how data relates to other data. Like what needs its own table, what can be a column, what breaks if you delete something. That kind of thinking is useful beyond just SQL.

Glad I took the class even if some of it was rough.
