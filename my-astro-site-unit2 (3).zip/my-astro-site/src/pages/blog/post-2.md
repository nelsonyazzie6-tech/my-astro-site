---
title: "What I Learned Building My First Astro Site"
pubDate: 2025-02-03
description: "Astro's file-based routing, component islands, and zero JS by default — a first impression from someone coming from plain HTML."
author: "Nelzony"
tags: ["web dev", "astro", "learning"]
---

# What I Learned Building My First Astro Site

I went into this not really knowing what Astro was. Figured it was just another framework. It's actually pretty different from what I expected.

## The file routing thing is nice

Every `.astro` file you put in `src/pages/` just becomes a URL. That's it. No extra setup.

```
src/pages/index.astro      →  /
src/pages/about.astro      →  /about/
src/pages/blog/index.astro →  /blog/
```

Coming from having to manually set up routes before, this was a relief.

## The frontmatter section

Each `.astro` file has a section at the top between `---` marks where you write JavaScript. That code runs when the site builds, not in the browser.

```astro
---
const name = "Nelzony";
const skills = ["HTML", "CSS", "JS"];
---

<h1>Hello, {name}</h1>
<ul>
  {skills.map(skill => <li>{skill}</li>)}
</ul>
```

The `{}` lets you drop variables right into the HTML. Once I got that it made a lot more sense.

## Markdown for posts

This was probably my favorite part. Instead of writing a whole `.astro` file for every blog post, you just write a `.md` file with some info at the top.

```markdown
---
title: "My Post"
pubDate: 2025-01-15
---

Just write normal text here. **Bold works**. Lists work. All of it.
```

Astro turns it into a page automatically. Pretty convenient.

## Scoped styles

You add a `<style>` tag at the bottom of your `.astro` file and the styles only apply to that page. Doesn't mess with anything else. That took me a second to understand but it makes sense once you see it working.

For styles that apply everywhere you just make a CSS file and import it.

## Overall

Honestly easier to get started with than I expected. Still figuring things out but the basics clicked faster than I thought they would.
