# My Astro Site — Unit 2

Personal website built with [Astro](https://astro.build) as part of the FLC CIS Web Development course.

## Unit 2 Requirements Checklist

- [x] **Requirement 1** — Created Astro pages: `src/pages/about.astro`, `src/pages/blog/index.astro`
- [x] **Requirement 2** — Three Markdown blog posts in `src/pages/blog/`
- [x] **Requirement 3** — Dynamic variables, `.map()`, and conditional rendering in `about.astro`
- [x] **Requirement 4** — Scoped `<style>` block in `about.astro`
- [x] **Requirement 5** — Global stylesheet at `src/styles/global.css`, imported in all pages

## Pages

| Page | Path | File |
|------|------|------|
| Home | `/` | `src/pages/index.astro` |
| About | `/about/` | `src/pages/about.astro` |
| Blog | `/blog/` | `src/pages/blog/index.astro` |
| Post 1 | `/blog/post-1/` | `src/pages/blog/post-1.md` |
| Post 2 | `/blog/post-2/` | `src/pages/blog/post-2.md` |
| Post 3 | `/blog/post-3/` | `src/pages/blog/post-3.md` |

## Getting Started

```bash
# Install dependencies
npm install

# Start the dev server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
my-astro-site/
├── src/
│   ├── pages/
│   │   ├── index.astro       ← Home page
│   │   ├── about.astro       ← About page (dynamic content + scoped styles)
│   │   └── blog/
│   │       ├── index.astro   ← Blog listing page
│   │       ├── post-1.md     ← Blog post 1
│   │       ├── post-2.md     ← Blog post 2
│   │       └── post-3.md     ← Blog post 3
│   └── styles/
│       └── global.css        ← Site-wide styles
├── public/
├── astro.config.mjs
├── package.json
└── tsconfig.json
```
